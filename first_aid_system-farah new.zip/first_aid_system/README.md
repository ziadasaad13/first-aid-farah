# First Aid System - Data & Storage Layer

نظام إدارة الملفات والبيانات (Storage & Data Management Layer) لمشروع نظام التوعية والإسعافات الأولية (First Aid System).

---

## 📁 هيكل البيانات (Data Structure)

```text
first_aid_system/
│
├── data/
│   ├── guides/                      # ملفات الإرشادات الطبية (78 ملف .txt بهيدر منظم)
│   ├── Clinics and contacts .csv    # أرقام الطوارئ والمستشفيات والمراكز المتخصصة (304 جهة)
│   ├── faqs.json                    # الأسئلة الشائعة وإجاباتها (375 سؤال وجواب)
│   ├── kaggle_first_aid.csv         # قاعدة بيانات كاجل للإسعافات (346 سؤال وجواب)
│   ├── Training_data.xlsx           # بيانات تدريب نماذج التصنيف (767 عينة)
│   ├── rules.json                   # قواعد الفرز الطبي وتحديد الخطورة (Triage Rules)
│   └── sources_log.csv              # سجل توثيق المصادر والمراجع الطبية
│
├── logs/
│   └── queries.log                  # سجل استعلامات المستخدمين (بدون بيانات شخصية)
│
├── backups/                         # نسخ احتياطية تلقائية عند التعديل
│
├── storage/
│   ├── __init__.py                  # تصدير كلاس StorageManager وكائن storage
│   └── storage.py                   # كود إدارة الملفات والبيانات بالكامل
│
└── demo_usage.py                    # سكريبت تجربة سريع لكافة الدوال
```

---

## 🚀 طريقة الاستخدام السريعة (Quick Usage)

يمكنك استدعاء كائن `storage` الجاهز مباشرة واستخدامه في أي جزء من المشروع:

```python
from storage import storage

# 1. تحميل الإرشادات الطبية (Medical Guides)
guides = storage.list_guides()

# 2. تحميل المستشفيات وأرقام الطوارئ (Clinics & Contacts)
contacts = storage.load_clinics_and_contacts()

# 3. تحميل الأسئلة الشائعة (FAQs)
faqs = storage.load_faqs()

# 4. تحميل قاعدة أسئلة كاجل (Kaggle Q&A)
kaggle_qa = storage.load_kaggle_first_aid()

# 5. تحميل بيانات تدريب الذكاء الاصطناعي (Training Data)
training_data = storage.load_training_data()

# 6. تحميل قواعد الفرز وتحديد الخطورة (Triage Rules)
rules = storage.load_rules()

# 7. تسجيل استعلام جديد في السجل (Query Logging)
storage.log_query(
    query="حرق ماء ساخن",
    condition="burn",
    severity="orange",
    response_time_ms=115,
    session_id="user_123"
)

# 8. طباعة تقرير شامل ببيانات النظام
print(storage.get_summary())
```

---

## 🧪 تشغيل كود التجربة

لتجربة تحميل كافة الملفات والتأكد من ربطها بالكامل:

```bash
python demo_usage.py
```
