"""
Storage Manager Module (Singleton Pattern)
Task: Member 4 - Data + File Handling
System: First Aid Awareness System
Course: Information Retrieval & Web Search
Author: Farah el-Sherbiny ( Data Architect)
"""

import os
import csv
import json
import shutil
import time
from datetime import datetime
from typing import Dict, List, Any, Optional


class StorageManager:
    """
    Singleton StorageManager to provide a unified data access layer
    for all team members (IR, Knowledge Base, ML, Backend, UI).
    """
    _instance = None

    def __new__(cls, base_dir: Optional[str] = None):
        if cls._instance is None:
            cls._instance = super(StorageManager, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self, base_dir: Optional[str] = None):
        if self._initialized:
            return

        if base_dir is None:
            # Locate root of first_aid_system relative to this file
            current_file_dir = os.path.dirname(os.path.abspath(__file__))
            self.base_dir = os.path.abspath(os.path.join(current_file_dir, ".."))
        else:
            self.base_dir = os.path.abspath(base_dir)

        self.data_dir = os.path.join(self.base_dir, "data")
        self.guides_dir = os.path.join(self.data_dir, "guides")
        self.logs_dir = os.path.join(self.base_dir, "logs")
        self.backup_dir = os.path.join(self.base_dir, "backups")

        for d in [self.data_dir, self.guides_dir, self.logs_dir, self.backup_dir]:
            os.makedirs(d, exist_ok=True)

        self.queries_log_path = os.path.join(self.logs_dir, "queries.log")
        self._initialized = True

    # ==========================================
    # 1. TXT Operations (Medical Guides)
    # ==========================================
    def load_guide(self, filename: str) -> Dict[str, Any]:
        """
        Loads a medical guide TXT file and parses its structured metadata header.
        Expected Header Format:
            TITLE: ...
            SOURCE: ...
            DATE_REVIEWED: ...
            URL: ...
            LANGUAGE: ...
            CONDITION_TAG: ...
            SEVERITY_TAGS: ...
            ---
            [Content Body]
        """
        filepath = os.path.join(self.guides_dir, filename)
        if not os.path.exists(filepath):
            raise FileNotFoundError(f"Guide file not found: {filepath}")

        metadata: Dict[str, Any] = {
            "filename": filename,
            "title": "",
            "source": "",
            "date_reviewed": "",
            "url": "",
            "language": "EN",
            "condition_tag": "",
            "severity_tags": [],
            "content": ""
        }

        with open(filepath, "r", encoding="utf-8") as f:
            lines = f.readlines()

        header_parsed = False
        body_lines = []

        for i, line in enumerate(lines):
            stripped = line.strip()
            if not header_parsed:
                if stripped == "---":
                    header_parsed = True
                    continue
                if ":" in stripped:
                    key, val = stripped.split(":", 1)
                    key = key.strip().upper()
                    val = val.strip()
                    if key == "TITLE":
                        metadata["title"] = val
                    elif key == "SOURCE":
                        metadata["source"] = val
                    elif key == "DATE_REVIEWED":
                        metadata["date_reviewed"] = val
                    elif key == "URL":
                        metadata["url"] = val
                    elif key == "LANGUAGE":
                        metadata["language"] = val
                    elif key == "CONDITION_TAG":
                        metadata["condition_tag"] = val
                    elif key == "SEVERITY_TAGS":
                        metadata["severity_tags"] = [t.strip() for t in val.split(",") if t.strip()]
            else:
                body_lines.append(line)

        metadata["content"] = "".join(body_lines).strip()
        return metadata

    def save_guide(self, filename: str, content: Dict[str, Any]) -> bool:
        """Saves or updates a guide file with automatic backup."""
        filepath = os.path.join(self.guides_dir, filename)
        if os.path.exists(filepath):
            self._backup(filepath)

        header_lines = [
            f"TITLE: {content.get('title', '')}",
            f"SOURCE: {content.get('source', '')}",
            f"DATE_REVIEWED: {content.get('date_reviewed', '')}",
            f"URL: {content.get('url', '')}",
            f"LANGUAGE: {content.get('language', 'EN')}",
            f"CONDITION_TAG: {content.get('condition_tag', '')}",
            f"SEVERITY_TAGS: {', '.join(content.get('severity_tags', []))}",
            "---",
            content.get("content", "")
        ]

        with open(filepath, "w", encoding="utf-8") as f:
            f.write("\n".join(header_lines))
        return True

    def list_guides(self) -> List[Dict[str, Any]]:
        """Returns metadata for all available guide files."""
        guides = []
        if not os.path.exists(self.guides_dir):
            return guides

        for fname in sorted(os.listdir(self.guides_dir)):
            if fname.endswith(".txt"):
                try:
                    guide_meta = self.load_guide(fname)
                    guides.append(guide_meta)
                except Exception as e:
                    print(f"Error loading guide {fname}: {e}")
        return guides

    # ==========================================
    # 2. CSV Operations
    # ==========================================
    def load_contacts(self) -> List[Dict[str, str]]:
        """Loads emergency contacts from contacts.csv."""
        filepath = os.path.join(self.data_dir, "contacts.csv")
        return self._read_csv_dict(filepath)

    def load_clinics(self) -> List[Dict[str, str]]:
        """Loads clinic details from clinics.csv."""
        filepath = os.path.join(self.data_dir, "clinics.csv")
        return self._read_csv_dict(filepath)

    def load_training_data(self) -> List[Dict[str, str]]:
        """Loads model training data from training_data.csv."""
        filepath = os.path.join(self.data_dir, "training_data.csv")
        return self._read_csv_dict(filepath)

    def load_sources_log(self) -> List[Dict[str, str]]:
        """Loads sources log from sources_log.csv."""
        filepath = os.path.join(self.data_dir, "sources_log.csv")
        return self._read_csv_dict(filepath)

    def _read_csv_dict(self, filepath: str) -> List[Dict[str, str]]:
        if not os.path.exists(filepath):
            return []
        rows = []
        with open(filepath, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(dict(row))
        return rows

    # ==========================================
    # 3. JSON Operations (Rules & Inverted Index)
    # ==========================================
    def load_rules(self) -> Dict[str, Any]:
        """Loads Knowledge Base triage rules from rules.json."""
        filepath = os.path.join(self.data_dir, "rules.json")
        if not os.path.exists(filepath):
            return {}
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_rules(self, rules: Dict[str, Any]) -> bool:
        """Saves triage rules to rules.json with automatic backup."""
        filepath = os.path.join(self.data_dir, "rules.json")
        if os.path.exists(filepath):
            self._backup(filepath)
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(rules, f, ensure_ascii=False, indent=2)
        return True

    def load_index(self) -> Dict[str, Any]:
        """Loads inverted index from data/inverted_index.json."""
        filepath = os.path.join(self.data_dir, "inverted_index.json")
        if not os.path.exists(filepath):
            return {}
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_index(self, index: Dict[str, Any]) -> bool:
        """Saves inverted index to data/inverted_index.json."""
        filepath = os.path.join(self.data_dir, "inverted_index.json")
        with open(filepath, "w", encoding="utf-8") as f:
            json.dump(index, f, ensure_ascii=False, indent=2)
        return True

    # ==========================================
    # 4. Logging & Privacy Protection
    # ==========================================
    def log_query(self, query: str, condition: str, severity: str, response_time_ms: int, session_id: str = "anon") -> None:
        """
        Logs queries to queries.log without any personal identifiable information (PII).
        Format:
        2024-01-15 14:32:11 | QUERY: "..." | CONDITION: ... | SEVERITY: ... | RESPONSE_TIME: ...ms | SESSION: ...
        """
        self._rotate_logs_if_needed()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        sanitized_query = query.replace("\n", " ").replace('"', "'").strip()
        log_entry = (
            f'{timestamp} | QUERY: "{sanitized_query}" | '
            f'CONDITION: {condition} | SEVERITY: {severity} | '
            f'RESPONSE_TIME: {response_time_ms}ms | SESSION: {session_id}\n'
        )

        with open(self.queries_log_path, "a", encoding="utf-8") as f:
            f.write(log_entry)

    def _rotate_logs_if_needed(self, max_bytes: int = 10 * 1024 * 1024) -> None:
        """Rotates queries.log if file size exceeds 10MB."""
        if os.path.exists(self.queries_log_path):
            if os.path.getsize(self.queries_log_path) >= max_bytes:
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                archived_name = f"queries_{ts}.log"
                archived_path = os.path.join(self.logs_dir, archived_name)
                shutil.move(self.queries_log_path, archived_path)

    # ==========================================
    # 5. Backup Mechanism
    # ==========================================
    def _backup(self, filepath: str) -> None:
        """Creates timestamped backup in backups/ before overwriting."""
        if not os.path.exists(filepath):
            return
        filename = os.path.basename(filepath)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{filename}_{ts}.bak"
        backup_path = os.path.join(self.backup_dir, backup_filename)
        shutil.copyfile(filepath, backup_path)
